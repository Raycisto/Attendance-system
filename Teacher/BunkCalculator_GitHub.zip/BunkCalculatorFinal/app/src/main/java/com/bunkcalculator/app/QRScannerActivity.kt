package com.bunkcalculator.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.FirebaseDatabase
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class QRScannerActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private var cameraControl: CameraControl? = null
    private var cameraInfo: CameraInfo? = null
    private lateinit var cameraExecutor: ExecutorService

    private var currentZoom = 1f
    private var currentExposureStep = 0
    private var scanningDone = false

    companion object {
        private const val CAMERA_PERM = 101
        private const val TAG = "QRScanner"
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cameraExecutor = Executors.newSingleThreadExecutor()

        window.statusBarColor = Color.parseColor("#0e0e14")
        window.navigationBarColor = Color.parseColor("#0e0e14")

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        setContentView(root)

        previewView = PreviewView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(previewView)

        val topLabel = TextView(this).apply {
            text = "Point camera at QR code"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#CC0e0e14"))
            setPadding(0, 52, 0, 18)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        }
        root.addView(topLabel)

        val controlBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#EE0e0e14"))
            setPadding(32, 24, 32, 40)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }
        root.addView(controlBar)

        val zoomBtn = styledButton("🔍 1x")
        zoomBtn.setOnClickListener {
            currentZoom += 1f
            if (currentZoom > 5f) currentZoom = 1f

            try {
                val maxZoom = cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f
                val safeZoom = currentZoom.coerceIn(1f, maxZoom)
                cameraControl?.setZoomRatio(safeZoom)
                zoomBtn.text = "🔍 ${safeZoom.toInt()}x"
            } catch (e: Exception) {
                Log.e(TAG, "Zoom error", e)
            }
        }

        val expBtn = styledButton("☀ EV 0")
        expBtn.setOnClickListener {
            currentExposureStep--
            if (currentExposureStep < -3) currentExposureStep = 0
            applyExposure()
            expBtn.text = "☀ EV $currentExposureStep"
        }

        val cancelBtn = styledButton("✕ Cancel")
        cancelBtn.setOnClickListener { finish() }

        controlBar.addView(zoomBtn)
        controlBar.addView(expBtn)
        controlBar.addView(cancelBtn)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERM)
        } else {
            startCamera()
        }
    }

    private fun styledButton(label: String): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2a2a3e"))
        }
    }

    private fun applyExposure() {
        val info = cameraInfo ?: return
        val range = info.exposureState.exposureCompensationRange

        val index = when (currentExposureStep) {
            0 -> 0
            -1 -> range.lower / 3
            -2 -> range.lower * 2 / 3
            -3 -> range.lower
            else -> 0
        }.coerceIn(range.lower, range.upper)

        try {
            cameraControl?.setExposureCompensationIndex(index)
        } catch (e: Exception) {
            Log.e(TAG, "Exposure error", e)
        }
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val scanner = BarcodeScanning.getClient()

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (scanningDone) {
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    val mediaImage = imageProxy.image
                    if (mediaImage == null) {
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    val image = InputImage.fromMediaImage(
                        mediaImage,
                        imageProxy.imageInfo.rotationDegrees
                    )

                    scanner.process(image)
                        .addOnSuccessListener { barcodes ->
                            for (barcode in barcodes) {
                                val value = barcode.rawValue
                                if (!value.isNullOrEmpty() && !scanningDone) {
                                    scanningDone = true

                                    // --- REAL FIREBASE CONNECTION ---
                                    try {
                                        // 1. Parse the JSON from the QR code
                                        val qrData = JSONObject(value)
                                        val sessionId = qrData.getString("sessionId")

                                        // 2. Connect to your specific database URL
                                        val databaseUrl = "YOUR_FIREBASE_REALTIME_DB_URL"
                                        val database = FirebaseDatabase.getInstance(databaseUrl)
                                        val studentsRef = database.getReference("sessions").child(sessionId).child("students")

                                        // 3. Prepare your attendance data
                                        val studentData = hashMapOf(
                                            "name" to "DIVYANSHU KAPRAWAN",
                                            "rollNo" to "25201300101",
                                            "time" to SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                                        )

                                        runOnUiThread {
                                            Toast.makeText(this@QRScannerActivity, "Marking Attendance...", Toast.LENGTH_SHORT).show()
                                        }

                                        // 4. Push to Firebase
                                        studentsRef.push().setValue(studentData)
                                            .addOnCompleteListener { task ->
                                                runOnUiThread {
                                                    if (task.isSuccessful) {
                                                        Toast.makeText(this@QRScannerActivity, "Attendance Marked ✓", Toast.LENGTH_LONG).show()
                                                    } else {
                                                        Toast.makeText(this@QRScannerActivity, "Network Error", Toast.LENGTH_SHORT).show()
                                                    }

                                                    // Pass the result back to MainActivity to update your UI
                                                    // Pass a friendly success message back to MainActivity
                                                    val intent = Intent()
                                                    intent.putExtra("qr", "✅ Attendance Marked Successfully!")
                                                    setResult(RESULT_OK, intent)
                                                    finish()
                                                }
                                            }

                                    } catch (e: Exception) {
                                        // If the QR code scanned isn't from the Teacher App (not valid JSON)
                                        Log.e(TAG, "Not an attendance QR code", e)
                                        runOnUiThread {
                                            val intent = Intent()
                                            intent.putExtra("qr", value)
                                            setResult(RESULT_OK, intent)
                                            finish()
                                        }
                                    }
                                    // --------------------------------
                                    break
                                }
                            }
                        }
                        .addOnFailureListener {
                            Log.e(TAG, "Scan failed", it)
                        }
                        .addOnCompleteListener {
                            imageProxy.close()
                        }
                }

                cameraProvider.unbindAll()

                val camera = cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )

                cameraControl = camera.cameraControl
                cameraInfo = camera.cameraInfo

            } catch (e: Exception) {
                Log.e(TAG, "Camera error", e)
                finish()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == CAMERA_PERM) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                finish()
            }
        }
    }
}