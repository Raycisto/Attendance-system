// ── QR Attendance Panel ──
// Injected AFTER login. Opens automatically, closes when bunk panel opens.
// Communicates with Android via window.AndroidBridge

(function () {
  if (document.getElementById("qr-panel-root")) return;

  let student = null;
  let panelVisible = false;

  // ── Inject Panel CSS ──
  const style = document.createElement("style");
  style.textContent = `
    #qr-panel-root {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: #0e0e14;
      z-index: 999998;
      display: none;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: white;
      font-family: 'Syne', sans-serif;
      gap: 18px;
    }
    #qr-panel-root h2 {
      font-size: 20px;
      font-weight: 800;
      margin: 0;
      background: linear-gradient(135deg, #6c63ff, #e040fb);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    #qr-student-card {
      background: #13131f;
      border: 1px solid #2a2a3e;
      border-radius: 14px;
      padding: 18px 28px;
      text-align: center;
      min-width: 240px;
    }
    #qr-student-name {
      font-size: 16px;
      font-weight: 700;
      color: #e2e2e2;
      margin-bottom: 4px;
    }
    #qr-student-id {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: #6c63ff;
    }
    #qr-status-msg {
      font-size: 12px;
      color: #555;
      font-style: italic;
    }
    .qr-btn {
      padding: 12px 28px;
      border-radius: 10px;
      border: none;
      cursor: pointer;
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: 14px;
      transition: transform 0.15s, opacity 0.15s;
    }
    .qr-btn:active { transform: scale(0.97); opacity: 0.85; }
    #qr-scan-btn {
      background: linear-gradient(135deg, #6c63ff, #e040fb);
      color: white;
      font-size: 15px;
    }
    #qr-scan-btn:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }
    #qr-close-btn {
      background: #1e1e2e;
      border: 1px solid #2a2a3e;
      color: #888;
      font-size: 13px;
    }
    #qr-success-msg {
      display: none;
      padding: 14px 24px;
      background: #0f2a1a;
      border: 1px solid #1a4d2e;
      border-radius: 10px;
      color: #4ade80;
      font-size: 13px;
      font-weight: 600;
      text-align: center;
    }
  `;
  document.head.appendChild(style);

  // ── Create Panel DOM ──
  const panel = document.createElement("div");
  panel.id = "qr-panel-root";
  panel.innerHTML = `
    <h2>📷 Attendance QR</h2>
    <div id="qr-student-card">
      <div id="qr-student-name">Loading...</div>
      <div id="qr-student-id"></div>
    </div>
    <div id="qr-status-msg">Fetching your details...</div>
    <button class="qr-btn" id="qr-scan-btn" disabled>📷 Scan QR Code</button>
    <div id="qr-success-msg"></div>
    <button class="qr-btn" id="qr-close-btn">Close</button>
  `;
  document.body.appendChild(panel);

  // ── Fetch Student Info from ERP ──
  async function fetchStudentInfo() {
    const res = await fetch(
      "https://student.gehu.ac.in/Account/GetStudentDetail",
      {
        method: "POST",
        credentials: "include",
        headers: { "x-requested-with": "XMLHttpRequest" }
      }
    );
    if (!res.ok) throw new Error("Not logged in or session expired.");
    const data = await res.json();

    let raw;
    if (typeof data.state === "string") raw = JSON.parse(data.state);
    else if (Array.isArray(data)) raw = data;
    else if (Array.isArray(data.data)) raw = data.data;
    else throw new Error("Unexpected student data format.");

    if (!raw || !raw[0]) throw new Error("Empty student record.");
    return raw[0];
  }

  // ── Open Panel ──
  async function openQRPanel() {
    panel.style.display = "flex";
    panelVisible = true;

    document.getElementById("qr-student-name").textContent = "Loading...";
    document.getElementById("qr-student-id").textContent = "";
    document.getElementById("qr-status-msg").textContent = "Fetching your details...";
    document.getElementById("qr-scan-btn").disabled = true;
    document.getElementById("qr-success-msg").style.display = "none";

    try {
      student = await fetchStudentInfo();
      document.getElementById("qr-student-name").textContent = student.StudentName || "Unknown";
      document.getElementById("qr-student-id").textContent = student.StudentID || "";
      document.getElementById("qr-status-msg").textContent = "Ready to scan";
      document.getElementById("qr-scan-btn").disabled = false;
    } catch (e) {
      document.getElementById("qr-student-name").textContent = "Error loading info";
      document.getElementById("qr-status-msg").textContent = e.message || "Something went wrong";
    }
  }

  // ── Close Panel ──
  function closeQRPanel() {
    panel.style.display = "none";
    panelVisible = false;
  }

  // ── Handle QR result returned from Android ──
  // Called by MainActivity after QR scanner activity returns
  window.handleScannedQR = function (qrData) {
    if (!student) return;

    const successEl = document.getElementById("qr-success-msg");
    successEl.style.display = "block";
    successEl.textContent = "✅ QR Scanned! Submitting...";

    // Send to backend — customize this URL/body for your Supabase or server
    const payload = {
      roll_no: student.StudentID,
      name: student.StudentName,
      qr_data: qrData,
      timestamp: new Date().toISOString()
    };

    fetch("https://YOUR_BACKEND_URL/attendance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(r => r.json())
      .then(() => {
        successEl.textContent = "✅ Attendance marked successfully!";
      })
      .catch(() => {
        // Even if backend fails, show scanned data
        successEl.textContent = "⚠️ Scanned: " + qrData.substring(0, 40);
      });
  };

  // ── Button Events ──
  document.addEventListener("click", function (e) {
    if (e.target && e.target.id === "qr-scan-btn") {
      if (!student) return;
      // Tell Android to open QR scanner
      if (window.AndroidBridge) {
        window.AndroidBridge.startQRScanner(
          JSON.stringify({
            roll_no: student.StudentID,
            name: student.StudentName
          })
        );
      } else {
        // Fallback for browser testing
        console.warn("AndroidBridge not available (testing in browser?)");
        window.handleScannedQR("TEST_QR_DATA_12345");
      }
    }

    if (e.target && e.target.id === "qr-close-btn") {
      closeQRPanel();
    }
  });

  // ── Expose global control (used by script.js FAB handler) ──
  window.QR_PANEL = {
    open: openQRPanel,
    close: closeQRPanel,
    isOpen: () => panelVisible
  };

  // ── Auto-open 1s after injection (login already verified by MainActivity) ──
  setTimeout(openQRPanel, 1000);

})();