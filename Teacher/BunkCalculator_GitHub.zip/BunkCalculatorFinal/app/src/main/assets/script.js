// ── Bunk Calculator — Combined Injected Script ──
(function() {
  if (document.getElementById("erp-enhancer-root")) return;

  const fontLink = document.createElement("link");
  fontLink.rel = "stylesheet";
  fontLink.href = "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@400;600;700;800&display=swap";
  document.head.appendChild(fontLink);

  const style = document.createElement("style");
  style.textContent = '/* =====================================================\n   GEHU ERP Enhancer\n   ===================================================== */\n\n#erp-enhancer-root{position:fixed;top:0;right:0;height:100vh;width:380px;z-index:999999;pointer-events:none;font-family:\'Syne\',sans-serif}\n#erp-fab{position:fixed;bottom:28px;right:28px;width:54px;height:54px;border-radius:50%;background:linear-gradient(135deg,#6c63ff,#e040fb);border:none;cursor:pointer;z-index:1000000;pointer-events:all;box-shadow:0 4px 24px rgba(108,99,255,.5);display:flex;align-items:center;justify-content:center;transition:transform .2s ease,box-shadow .2s ease;color:#fff;font-size:22px;animation:erp-pulse-fab 2.5s ease-in-out infinite}\n#erp-fab:hover{transform:scale(1.1);box-shadow:0 6px 32px rgba(108,99,255,.7)}\n#erp-fab.open{animation:none;background:linear-gradient(135deg,#e040fb,#6c63ff)!important}\n#erp-panel{position:fixed;top:0;right:-400px;width:380px;height:100vh;background:#0e0e14;border-left:1px solid #2a2a3e;box-shadow:-8px 0 48px rgba(0,0,0,.6);z-index:999999;pointer-events:all;transition:right .35s cubic-bezier(.22,1,.36,1);display:flex;flex-direction:column;overflow:hidden;will-change:right}\n#erp-panel.visible{right:0;animation:erp-slide-in .38s cubic-bezier(.22,1,.36,1) both}\n.erp-header{padding:20px 20px 14px;background:linear-gradient(135deg,#13131f,#1a1a2e);border-bottom:1px solid #2a2a3e;flex-shrink:0;backdrop-filter:blur(10px)}\n.erp-header-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}\n.erp-logo{display:flex;align-items:center;gap:10px}\n.erp-logo-icon{width:32px;height:32px;background:linear-gradient(135deg,#6c63ff,#e040fb);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}\n.erp-logo-text{font-size:15px;font-weight:800;color:#fff;letter-spacing:-.3px}\n.erp-logo-sub{font-size:10px;font-weight:400;color:#666;letter-spacing:1px;text-transform:uppercase;margin-top:1px}\n#erp-close-btn{background:#1e1e2e;border:1px solid #2a2a3e;color:#888;width:28px;height:28px;border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;transition:all .15s}\n#erp-close-btn:hover{background:#2a2a3e;color:#fff}\n.erp-tabs{display:flex;gap:6px;background:#0e0e14;padding:0 20px 14px;border-bottom:1px solid #1e1e2e;flex-shrink:0}\n.erp-tab{flex:1;padding:7px 4px;border:1px solid #2a2a3e;background:transparent;color:#555;font-family:\'Syne\',sans-serif;font-size:11px;font-weight:600;letter-spacing:.3px;cursor:pointer;border-radius:6px;transition:all .2s;text-align:center}\n.erp-tab:hover{color:#aaa;border-color:#444}\n.erp-tab.active{background:linear-gradient(135deg,#6c63ff22,#e040fb22);border-color:#6c63ff;color:#c5bfff;box-shadow:0 0 12px rgba(108,99,255,.3)}\n.erp-summary{padding:12px 20px;display:flex;gap:10px;background:#0e0e14;border-bottom:1px solid #1e1e2e;flex-shrink:0}\n.erp-stat-card{flex:1;background:#13131f;border:1px solid #2a2a3e;border-radius:8px;padding:10px 8px;text-align:center}\n.erp-stat-val{font-family:\'JetBrains Mono\',monospace;font-size:18px;font-weight:700;color:#fff;line-height:1;animation:erp-count-pop .4s cubic-bezier(.22,1,.36,1) both;animation-delay:.15s}\n.erp-stat-val.good{color:#4ade80}.erp-stat-val.bad{color:#f87171}\n.erp-stat-label{font-size:9px;font-weight:600;color:#444;text-transform:uppercase;letter-spacing:.8px;margin-top:4px}\n.erp-body{flex:1;overflow-y:auto;padding:12px 14px;scrollbar-width:thin;scrollbar-color:#2a2a3e #0e0e14}\n.erp-body::-webkit-scrollbar{width:4px}.erp-body::-webkit-scrollbar-track{background:#0e0e14}.erp-body::-webkit-scrollbar-thumb{background:#2a2a3e;border-radius:4px}\n.erp-subject-card{background:#13131f;border:1px solid #1e1e2e;border-radius:10px;padding:14px;margin-bottom:10px;position:relative;overflow:hidden;animation:erp-card-in .35s cubic-bezier(.22,1,.36,1) both;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease}\n.erp-subject-card:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(0,0,0,.4)}\n.erp-subject-card::before{content:\'\';position:absolute;left:0;top:0;bottom:0;width:3px;border-radius:3px 0 0 3px}\n.erp-subject-card.card-safe::before{background:#4ade80}.erp-subject-card.card-ok::before{background:#60a5fa}.erp-subject-card.card-risk::before{background:#facc15}.erp-subject-card.card-danger::before{background:#f87171}\n.erp-subject-card.card-safe:hover{border-color:#4ade8066;box-shadow:0 8px 24px rgba(74,222,128,.1)}\n.erp-subject-card.card-ok:hover{border-color:#60a5fa66;box-shadow:0 8px 24px rgba(96,165,250,.1)}\n.erp-subject-card.card-risk:hover{border-color:#facc1566;box-shadow:0 8px 24px rgba(250,204,21,.1)}\n.erp-subject-card.card-danger:hover{border-color:#f8717166;box-shadow:0 8px 24px rgba(248,113,113,.1)}\n.erp-subject-card:nth-child(1){animation-delay:.03s}.erp-subject-card:nth-child(2){animation-delay:.07s}.erp-subject-card:nth-child(3){animation-delay:.11s}.erp-subject-card:nth-child(4){animation-delay:.15s}.erp-subject-card:nth-child(5){animation-delay:.19s}.erp-subject-card:nth-child(6){animation-delay:.23s}.erp-subject-card:nth-child(7){animation-delay:.27s}.erp-subject-card:nth-child(8){animation-delay:.31s}\n.erp-subject-name{font-size:12px;font-weight:700;color:#e2e2e2;margin-bottom:10px;line-height:1.3}\n.erp-progress-wrap{background:#1e1e2e;border-radius:4px;height:6px;margin-bottom:10px;overflow:hidden;position:relative}\n.erp-progress-bar{height:100%;border-radius:4px;transition:width .6s cubic-bezier(.22,1,.36,1);animation:erp-bar-grow .7s cubic-bezier(.22,1,.36,1) both;animation-delay:.2s}\n.bar-safe{background:linear-gradient(90deg,#4ade80,#22c55e)}.bar-ok{background:linear-gradient(90deg,#60a5fa,#3b82f6)}.bar-risk{background:linear-gradient(90deg,#facc15,#eab308)}.bar-danger{background:linear-gradient(90deg,#f87171,#ef4444)}\n.erp-threshold-marker{position:absolute;top:0;bottom:0;left:75%;width:1px;background:rgba(255,255,255,.15)}\n.erp-subject-row{display:flex;align-items:center;justify-content:space-between}\n.erp-attend-info{font-family:\'JetBrains Mono\',monospace;font-size:11px;color:#666}\n.erp-pct{font-family:\'JetBrains Mono\',monospace;font-size:13px;font-weight:700}\n.erp-pct.safe{color:#4ade80}.erp-pct.ok{color:#60a5fa}.erp-pct.risk{color:#facc15}.erp-pct.danger{color:#f87171}\n.erp-chips{display:flex;gap:6px;margin-top:10px;flex-wrap:wrap}\n.erp-chip{display:flex;align-items:center;gap:5px;padding:4px 8px;border-radius:5px;font-size:10px;font-weight:600;border:1px solid transparent;animation:erp-fade-up .3s ease both;animation-delay:.35s}\n.chip-bunk{background:#0f2a1a;border-color:#1a4d2e;color:#4ade80}.chip-need{background:#2a1a0f;border-color:#4d2e1a;color:#fb923c}.chip-zero{background:#1a1a2e;border-color:#2a2a4e;color:#888;font-style:italic}\n.erp-error{margin:20px;padding:14px;background:#1a0f0f;border:1px solid #4d1a1a;border-radius:8px;color:#f87171;font-size:12px;line-height:1.6;text-align:center}\n.erp-error-icon{font-size:24px;margin-bottom:8px}\n.erp-footer{padding:10px 20px;border-top:1px solid #1e1e2e;display:flex;align-items:center;justify-content:space-between;flex-shrink:0}\n.erp-refresh-btn{background:#1e1e2e;border:1px solid #2a2a3e;color:#888;padding:6px 12px;border-radius:6px;font-size:11px;font-family:\'Syne\',sans-serif;font-weight:600;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:5px}\n.erp-refresh-btn:hover{background:#2a2a3e;color:#fff}\n.erp-refresh-btn.spinning .erp-refresh-icon{animation:erp-spin .6s linear infinite}\n.erp-last-updated{font-size:10px;color:#333;font-family:\'JetBrains Mono\',monospace}\n.erp-section-hdr{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#333;padding:8px 0 4px;border-bottom:1px solid #1e1e2e;margin-bottom:10px}\n.erp-skeleton{background:linear-gradient(90deg,#13131f 25%,#1e1e2e 50%,#13131f 75%);background-size:400px 100%;animation:erp-shimmer 1.4s infinite;border-radius:6px;height:12px;margin-bottom:8px}\n.erp-skeleton.tall{height:70px;border-radius:10px}.erp-skeleton.short{width:60%}\n.erp-live-dot{display:inline-block;width:6px;height:6px;background:#4ade80;border-radius:50%;margin-right:5px;animation:erp-pulse-dot 1.5s ease-in-out infinite}\n@keyframes erp-spin{to{transform:rotate(360deg)}}\n@keyframes erp-slide-in{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}\n@keyframes erp-fade-up{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}\n@keyframes erp-shimmer{0%{background-position:-400px 0}100%{background-position:400px 0}}\n@keyframes erp-pulse-fab{0%,100%{box-shadow:0 4px 24px rgba(108,99,255,.5)}50%{box-shadow:0 4px 40px rgba(108,99,255,.9),0 0 0 8px rgba(108,99,255,.15)}}\n@keyframes erp-bar-grow{from{width:0%!important}}\n@keyframes erp-count-pop{0%{transform:scale(.7);opacity:0}60%{transform:scale(1.15)}100%{transform:scale(1);opacity:1}}\n@keyframes erp-card-in{from{opacity:0;transform:translateY(16px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}\n@keyframes erp-pulse-dot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}\n@media(max-width:420px){#erp-panel{width:100vw;right:-100vw}#erp-enhancer-root{width:100vw}}\n';
  document.head.appendChild(style);

  // ── Calculator Utilities ──
  function calculateSafeBunks(attended, total) {
    if (total === 0) return 0;
    return Math.max(0, Math.floor(attended / 0.75 - total));
  }
  function calculateClassesNeeded(attended, total) {
    if (total === 0) return 0;
    if (attended / total >= 0.75) return 0;
    return Math.max(0, Math.ceil((0.75 * total - attended) / 0.25));
  }
  function getStatus(pct) {
    const p = parseFloat(pct);
    if (p >= 90) return { label: "Safe" };
    if (p >= 75) return { label: "OK" };
    if (p >= 60) return { label: "At Risk" };
    return { label: "Danger" };
  }

  let subjects = [];
  let currentView = "overview";
  let lastUpdated = null;

  function normalizeSubject(raw) {
    const att = parseInt(raw.TotalPresent, 10) || 0;
    const tot = parseInt(raw.TotalLecture, 10) || 0;
    const name = raw.Subject || "Unknown Subject";
    const pct = parseFloat(raw.Percentage || 0);
    const status = getStatus(pct);
    return { name, attended: att, total: tot, pct, status, bunks: calculateSafeBunks(att, tot), needed: calculateClassesNeeded(att, tot) };
  }

  async function fetchAttendance() {
    const res = await fetch(
      "https://student.gehu.ac.in/Student/GetSubjectDetailStudentAcademicFromLive",
      { method: "POST", credentials: "include", headers: { "x-requested-with": "XMLHttpRequest" } }
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    let raw;
    if (typeof data.state === "string") raw = JSON.parse(data.state);
    else if (Array.isArray(data)) raw = data;
    else if (Array.isArray(data.data)) raw = data.data;
    else throw new Error("Unexpected API response format.");
    if (!Array.isArray(raw) || raw.length === 0) throw new Error("No attendance records found.");
    return raw.map(normalizeSubject);
  }

  const cardCls  = {"Safe":"card-safe","OK":"card-ok","At Risk":"card-risk","Danger":"card-danger"};
  const barCls   = {"Safe":"bar-safe","OK":"bar-ok","At Risk":"bar-risk","Danger":"bar-danger"};
  const pctCls   = {"Safe":"safe","OK":"ok","At Risk":"risk","Danger":"danger"};

  function renderCard(sub) {
    const bunkChip = sub.bunks > 0
      ? `<span class="erp-chip chip-bunk">🟢 Can bunk <strong>${sub.bunks}</strong> more</span>`
      : `<span class="erp-chip chip-zero">🚫 No safe bunks</span>`;
    const needChip = sub.needed > 0
      ? `<span class="erp-chip chip-need">📚 Need <strong>${sub.needed}</strong> more</span>`
      : `<span class="erp-chip chip-zero">✅ 75% achieved</span>`;
    return `
      <div class="erp-subject-card ${cardCls[sub.status.label]||"card-ok"}">
        <div class="erp-subject-name">${sub.name}</div>
        <div class="erp-progress-wrap">
          <div class="erp-progress-bar ${barCls[sub.status.label]||"bar-ok"}" style="width:${Math.min(sub.pct,100)}%"></div>
          <div class="erp-threshold-marker"></div>
        </div>
        <div class="erp-subject-row">
          <span class="erp-attend-info">${sub.attended} / ${sub.total} classes</span>
          <span class="erp-pct ${pctCls[sub.status.label]||"ok"}">${sub.pct}%</span>
        </div>
        <div class="erp-chips">${bunkChip}${needChip}</div>
      </div>`;
  }

  function renderSummary() {
    if (!subjects.length) return "";
    const avg = (subjects.reduce((a,s)=>a+parseFloat(s.pct),0)/subjects.length).toFixed(1);
    const totalBunks = subjects.reduce((a,s)=>a+s.bunks,0);
    const below = subjects.filter(s=>parseFloat(s.pct)<75).length;
    return `<div class="erp-summary">
      <div class="erp-stat-card"><div class="erp-stat-val ${parseFloat(avg)>=75?"good":"bad"}">${avg}%</div><div class="erp-stat-label">Avg Att.</div></div>
      <div class="erp-stat-card"><div class="erp-stat-val ${totalBunks>0?"good":"bad"}">${totalBunks}</div><div class="erp-stat-label">Safe Bunks</div></div>
      <div class="erp-stat-card"><div class="erp-stat-val ${below===0?"good":"bad"}">${below}</div><div class="erp-stat-label">Below 75%</div></div>
    </div>`;
  }

  function renderSubjectList() {
    if (!subjects.length) return '<div class="erp-error">No subjects found.</div>';
    let sorted = [...subjects];
    if (currentView === "bunk") sorted.sort((a,b)=>b.bunks-a.bunks);
    else if (currentView === "needed") {
      sorted = sorted.filter(s=>s.needed>0).sort((a,b)=>b.needed-a.needed);
      if (!sorted.length) return `<div class="erp-error" style="background:#0f2a1a;border-color:#1a4d2e;color:#4ade80"><div class="erp-error-icon">🎉</div>All subjects above 75%!</div>`;
    }
    return sorted.map(renderCard).join("");
  }

  function updatePanel() {
    document.querySelectorAll(".erp-tab").forEach(t=>t.classList.toggle("active",t.dataset.view===currentView));
    const s = document.getElementById("erp-summary-area");
    if (s) s.innerHTML = renderSummary();
    const b = document.getElementById("erp-body-area");
    const hdr = currentView==="bunk"?`<div class="erp-section-hdr">Sorted by safe bunks</div>`:currentView==="needed"?`<div class="erp-section-hdr">Below 75%</div>`:"";
    if (b) b.innerHTML = hdr + renderSubjectList();
    const ts = document.getElementById("erp-timestamp");
    if (ts && lastUpdated) ts.innerHTML = `<span class="erp-live-dot"></span>${lastUpdated.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}`;
  }

  function showLoading() {
    const s = document.getElementById("erp-summary-area"); if(s) s.innerHTML="";
    const b = document.getElementById("erp-body-area");
    if(b) b.innerHTML=`<div class="erp-skeleton tall"></div><div class="erp-skeleton tall"></div><div class="erp-skeleton tall"></div><div class="erp-skeleton short"></div>`;
  }

  function showError(msg) {
    const b = document.getElementById("erp-body-area");
    if(b) b.innerHTML=`<div class="erp-error"><div class="erp-error-icon">⚠️</div><strong>Couldn't load attendance</strong><br><br>${msg}<br><br><small>Make sure you're logged into ERP.</small></div>`;
  }

  async function loadData() {
    const btn = document.getElementById("erp-refresh-btn");
    if(btn) btn.classList.add("spinning");
    showLoading();
    try {
      subjects = await fetchAttendance();
      lastUpdated = new Date();
      updatePanel();
    } catch(err) {
      showError(err.message || String(err));
    } finally {
      if(btn) btn.classList.remove("spinning");
    }
  }

  function buildPanel() {
    const panel = document.createElement("div");
    panel.id = "erp-panel";
    panel.dataset.view = "overview";
    panel.innerHTML = `
      <div class="erp-header">
        <div class="erp-header-top">
          <div class="erp-logo">
            <div class="erp-logo-icon">📊</div>
            <div><div class="erp-logo-text">Bunk Calculator</div><div class="erp-logo-sub">GEHU Attendance Tracker</div></div>
          </div>
          <button id="erp-close-btn">✕</button>
        </div>
        <div class="erp-tabs">
          <button class="erp-tab active" data-view="overview">Overview</button>
          <button class="erp-tab" data-view="bunk">🟢 Bunk</button>
          <button class="erp-tab" data-view="needed">📚 Needed</button>
        </div>
      </div>
      <div id="erp-summary-area"></div>
      <div class="erp-body" id="erp-body-area">
        <div class="erp-skeleton tall"></div><div class="erp-skeleton tall"></div><div class="erp-skeleton short"></div>
      </div>
      <div class="erp-footer">
        <button class="erp-refresh-btn" id="erp-refresh-btn"><span class="erp-refresh-icon">⟳</span> Refresh</button>
        <span class="erp-last-updated">Updated: <span id="erp-timestamp">—</span></span>
      </div>`;
    return panel;
  }

  function buildFab() {
    const fab = document.createElement("button");
    fab.id = "erp-fab";
    fab.title = "Open Bunk Calculator";
    fab.innerHTML = "📊";
    return fab;
  }

  function openPanel(panel, fab) {
    panel.classList.add("visible");
    fab.classList.add("open");
    fab.innerHTML = "✕";
  }

  function closePanel(panel, fab) {
    panel.classList.remove("visible");
    fab.classList.remove("open");
    fab.innerHTML = "📊";
  }

  function wireEvents(panel, fab) {
    fab.addEventListener("click", () => {
      // ── Close QR panel if open ──
      if (window.QR_PANEL && window.QR_PANEL.isOpen()) {
        window.QR_PANEL.close();
      }
      if (panel.classList.contains("visible")) {
        closePanel(panel, fab);
      } else {
        openPanel(panel, fab);
        if (!subjects.length) loadData();
      }
    });
    document.getElementById("erp-close-btn").addEventListener("click", () => closePanel(panel, fab));
    panel.querySelectorAll(".erp-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        currentView = tab.dataset.view;
        panel.dataset.view = currentView;
        updatePanel();
      });
    });
    document.getElementById("erp-refresh-btn").addEventListener("click", loadData);
  }

  function init() {
    const root = document.createElement("div");
    root.id = "erp-enhancer-root";
    const panel = buildPanel();
    const fab = buildFab();
    document.body.appendChild(root);
    document.body.appendChild(panel);
    document.body.appendChild(fab);
    wireEvents(panel, fab);
    // ── Bunk panel does NOT auto-open. QR panel opens first after login. ──
    // ── User opens bunk panel manually via the 📊 FAB button. ──
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();