# BunkCalculator — Attendance & QR Scanner App

An Android app for GEHU students that:
- Loads the student portal (student.gehu.ac.in) in a native WebView with a custom JS-injected bunk calculator UI
- Scans QR codes to mark attendance via Firebase Realtime Database
- Calculates how many classes you can bunk while staying above the required attendance %

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Android (UI) | Kotlin, WebView, CameraX |
| QR Scanning | ML Kit Barcode Scanning |
| Backend/DB | Firebase Realtime Database |
| Web layer | JavaScript (script.js, qr_panel.js) injected into WebView |

---

## Project Structure

```
BunkCalculatorFinal/
├── app/src/main/
│   ├── java/com/bunkcalculator/app/
│   │   ├── MainActivity.kt          ← WebView + JS bridge + bunk calculator
│   │   └── QRScannerActivity.kt     ← CameraX + ML Kit QR scanner + Firebase write
│   ├── assets/
│   │   ├── script.js                ← Bunk calculator UI injected into student portal
│   │   └── qr_panel.js              ← QR attendance panel UI
│   ├── res/
│   │   ├── layout/activity_main.xml
│   │   ├── drawable/                ← App icons
│   │   └── values/                  ← strings, styles
│   └── AndroidManifest.xml
├── app/google-services.json         ← ⚠️ PLACEHOLDER — replace with your own
├── app/build.gradle
├── build.gradle
├── settings.gradle
└── gradle/wrapper/
```

---

## Setup Instructions

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/BunkCalculator.git
cd BunkCalculator
```

### 2. Set up Firebase (required — use your own project)

> ⚠️ The `google-services.json` in this repo is a **placeholder**. Replace it.

1. Go to [Firebase Console](https://console.firebase.google.com) → Create a project
2. Add an Android app with package name `com.bunkcalculator.app`
3. Enable **Realtime Database** in your Firebase project
4. Download `google-services.json` → place in `app/`
5. In `QRScannerActivity.kt`, replace `YOUR_FIREBASE_REALTIME_DB_URL` with your actual Realtime DB URL

### 3. Open in Android Studio
- Open Android Studio → File → Open → select `BunkCalculatorFinal/`
- Let Gradle sync
- Run on a device or emulator (API 24+, camera required for QR scanning)

---

## How It Works

**Bunk Calculator:**
- Loads `https://student.gehu.ac.in/` in a WebView
- Injects `script.js` which fetches subject-wise attendance from the GEHU API and overlays a bunk calculator showing how many classes you can skip per subject

**QR Attendance:**
- Opens camera via CameraX
- ML Kit decodes QR codes in real time
- On successful scan, writes attendance record to Firebase Realtime Database

---

## Notes
- This app is built for GEHU students — the student portal URL and API endpoints are GEHU-specific
- The app requires camera permission for QR scanning
- Firebase Realtime Database rules should be configured appropriately for your use case
