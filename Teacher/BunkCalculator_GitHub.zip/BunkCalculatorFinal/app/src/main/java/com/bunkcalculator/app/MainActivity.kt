package com.bunkcalculator.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.*
import android.webkit.CookieManager
import android.os.Build
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // ── QR Scanner result launcher (replaces deprecated startActivityForResult) ──
    private val qrScannerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val qrData = result.data?.getStringExtra("qr") ?: return@registerForActivityResult
            // Escape the string safely for JS injection
            val escaped = qrData
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
            webView.evaluateJavascript("window.handleScannedQR('$escaped')", null)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full-screen immersive
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.parseColor("#0e0e14")
        window.navigationBarColor = Color.parseColor("#0e0e14")

        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        setupWebView()
        webView.loadUrl("https://student.gehu.ac.in/")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.setBackgroundColor(Color.parseColor("#0e0e14"))
        webView.webChromeClient = WebChromeClient()

        // ── Attach Android ↔ JS Bridge ──
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()

                val isLoginPage = url?.contains("Login", ignoreCase = true) == true
                        || url?.contains("Account", ignoreCase = true) == true
                        || url == "https://student.gehu.ac.in/"
                        || url == "https://student.gehu.ac.in"

                if (!isLoginPage) {
                    injectScripts()
                }
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return false
            }
        }
    }

    // ── Inject both JS files: QR panel first, then bunk calculator ──
    private fun injectScripts() {
        val qrScript = loadAsset("qr_panel.js")
        val bunkScript = loadAsset("script.js")

        if (qrScript != null) {
            webView.evaluateJavascript(qrScript, null)
        }
        // Inject bunk script 300ms later so QR_PANEL global is ready
        webView.postDelayed({
            if (bunkScript != null) {
                webView.evaluateJavascript(bunkScript, null)
            }
        }, 300)
    }

    private fun loadAsset(fileName: String): String? {
        return try {
            val sb = StringBuilder()
            val reader = BufferedReader(InputStreamReader(assets.open(fileName)))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                sb.append(line).append("\n")
            }
            reader.close()
            sb.toString()
        } catch (e: Exception) {
            null
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ── JS Interface: methods callable from JavaScript via window.AndroidBridge ──
    inner class AndroidBridge(private val activity: Activity) {

        @JavascriptInterface
        fun startQRScanner(studentJson: String) {
            // Must run on UI thread because we're starting an Activity
            activity.runOnUiThread {
                val intent = Intent(activity, QRScannerActivity::class.java)
                intent.putExtra("student", studentJson)
                qrScannerLauncher.launch(intent)
            }
        }

        // Optional: call this from JS to log messages during development
        @JavascriptInterface
        fun log(message: String) {
            android.util.Log.d("WebViewJS", message)
        }
    }
}